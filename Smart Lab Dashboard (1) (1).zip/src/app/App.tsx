import { RouterProvider } from "react-router";
import { router } from "./routes";
import { AuthProvider } from "./contexts/AuthContext";
import { DataLogProvider } from "./contexts/DataLogContext";
import { Toaster } from "./components/ui/sonner";

export default function App() {
  return (
    <AuthProvider>
      <DataLogProvider>
        <RouterProvider router={router} />
        <Toaster />
      </DataLogProvider>
    </AuthProvider>
  );
}