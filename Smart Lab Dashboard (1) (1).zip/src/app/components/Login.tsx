import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../contexts/AuthContext';
import { FlaskConical, Eye, EyeOff, LogIn } from 'lucide-react';

export function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    const result = await login(email, password);
    
    if (result.success) {
      navigate('/', { replace: true });
    } else {
      setError(result.error || 'Login failed');
    }
    
    setIsLoading(false);
  };

  const demoAccounts = [
    { role: 'Admin', email: 'admin@smartlab.com', password: 'admin123', description: 'Full system access' },
    { role: 'Manager', email: 'manager@smartlab.com', password: 'manager123', description: 'Labs 1-3 (Chemistry, Biology, Physics)' },
    { role: 'Manager 2', email: 'manager2@smartlab.com', password: 'manager123', description: 'Labs 4-6 (Computer, Research, Materials)' },
    { role: 'Technician', email: 'tech@smartlab.com', password: 'tech123', description: 'Equipment control' },
    { role: 'Viewer', email: 'viewer@smartlab.com', password: 'viewer123', description: 'Read-only access' },
  ];

  const quickLogin = (demoEmail: string, demoPassword: string) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-slate-50 to-blue-50 flex items-center justify-center p-4">
      <div className="w-full max-w-5xl grid lg:grid-cols-2 gap-8">
        {/* Login Form */}
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center">
              <FlaskConical className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-slate-900">Smart Lab Dashboard</h1>
              <p className="text-sm text-slate-500">Sign in to access your workspace</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-800">{error}</p>
              </div>
            )}

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">
                Email Address
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                placeholder="you@example.com"
                required
                disabled={isLoading}
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-slate-700 mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 pr-12 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                  placeholder="Enter your password"
                  required
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
                  disabled={isLoading}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Signing in...
                </>
              ) : (
                <>
                  <LogIn className="w-5 h-5" />
                  Sign In
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-slate-200">
            <p className="text-xs text-slate-500 text-center">
              Demo application with mock authentication
            </p>
          </div>
        </div>

        {/* Demo Accounts */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">Demo Accounts</h2>
            <p className="text-sm text-slate-600 mb-6">
              Click on any account below to auto-fill credentials and test role-based access control.
            </p>

            <div className="space-y-3">
              {demoAccounts.map((account, index) => (
                <button
                  key={index}
                  onClick={() => quickLogin(account.email, account.password)}
                  className="w-full text-left p-4 border-2 border-slate-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all group"
                  disabled={isLoading}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="font-medium text-slate-900 group-hover:text-blue-700 transition-colors">
                        {account.role}
                      </div>
                      <div className="text-xs text-slate-500 mt-1">{account.description}</div>
                    </div>
                    <div className="text-xs px-2 py-1 bg-slate-100 text-slate-600 rounded group-hover:bg-blue-100 group-hover:text-blue-700 transition-colors">
                      Click to fill
                    </div>
                  </div>
                  <div className="text-xs text-slate-600 mt-2 pt-2 border-t border-slate-100">
                    <div className="mb-1">📧 {account.email}</div>
                    <div>🔑 {account.password}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl shadow-xl p-6 text-white">
            <h3 className="font-semibold mb-3">Role Permissions</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-blue-300">•</span>
                <span><strong>Admin:</strong> Full access including user management & system settings</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-300">•</span>
                <span><strong>Manager:</strong> Lab & equipment management, reporting</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-300">•</span>
                <span><strong>Technician:</strong> Equipment control & maintenance updates</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-300">•</span>
                <span><strong>Viewer:</strong> Read-only dashboard access</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}