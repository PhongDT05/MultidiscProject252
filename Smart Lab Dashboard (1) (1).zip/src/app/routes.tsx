import { createBrowserRouter } from "react-router";
import { ProtectedLayout } from "./components/ProtectedLayout";
import { MainDashboard } from "./components/MainDashboard";
import { RoomDetail } from "./components/RoomDetail";
import { UserManagement } from "./components/UserManagement";
import { SystemConfig } from "./components/SystemConfig";
import { ThresholdConfig } from "./components/ThresholdConfig";
import { DeviceHealth } from "./components/DeviceHealth";
import { AlertCenter } from "./components/AlertCenter";
import { NotFound } from "./components/NotFound";
import { Login } from "./components/Login";
import { Unauthorized } from "./components/Unauthorized";

export const router = createBrowserRouter([
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/unauthorized",
    element: <Unauthorized />,
  },
  {
    path: "/",
    element: <ProtectedLayout />,
    children: [
      { index: true, element: <MainDashboard /> },
      { path: "room/:roomId", element: <RoomDetail /> },
      { path: "users", element: <UserManagement /> },
      { path: "config", element: <SystemConfig /> },
      { path: "thresholds", element: <ThresholdConfig /> },
      { path: "devices", element: <DeviceHealth /> },
      { path: "alerts", element: <AlertCenter /> },
      { path: "*", element: <NotFound /> },
    ],
  },
]);
