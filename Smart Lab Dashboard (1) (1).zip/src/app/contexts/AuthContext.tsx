import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type UserRole = 'admin' | 'manager' | 'technician' | 'viewer';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  avatar?: string;
  assignedLabs?: string[]; // Lab IDs this user can access (null/undefined = all labs for admin)
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  hasPermission: (requiredRole: UserRole) => boolean;
  hasAnyPermission: (roles: UserRole[]) => boolean;
  canAccessLab: (labId: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Role hierarchy: admin > manager > technician > viewer
const roleHierarchy: Record<UserRole, number> = {
  admin: 4,
  manager: 3,
  technician: 2,
  viewer: 1,
};

// Mock user database
const mockUsers: Record<string, { password: string; user: User }> = {
  'admin@smartlab.com': {
    password: 'admin123',
    user: {
      id: '1',
      email: 'admin@smartlab.com',
      name: 'Dr. Sarah Chen',
      role: 'admin',
      assignedLabs: undefined, // Admin has access to all labs
    },
  },
  'manager@smartlab.com': {
    password: 'manager123',
    user: {
      id: '2',
      email: 'manager@smartlab.com',
      name: 'John Martinez',
      role: 'manager',
      assignedLabs: ['lab-01', 'lab-02', 'lab-03'], // Chemistry, Biology, Physics Labs
    },
  },
  'manager2@smartlab.com': {
    password: 'manager123',
    user: {
      id: '5',
      email: 'manager2@smartlab.com',
      name: 'Lisa Anderson',
      role: 'manager',
      assignedLabs: ['lab-04', 'lab-05', 'lab-06'], // Computer, Research, Materials Labs
    },
  },
  'tech@smartlab.com': {
    password: 'tech123',
    user: {
      id: '3',
      email: 'tech@smartlab.com',
      name: 'Emily Watson',
      role: 'technician',
      assignedLabs: undefined, // Technicians have access to all labs
    },
  },
  'viewer@smartlab.com': {
    password: 'viewer123',
    user: {
      id: '4',
      email: 'viewer@smartlab.com',
      name: 'Alex Johnson',
      role: 'viewer',
      assignedLabs: undefined, // Viewers can see all labs (read-only)
    },
  },
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load user from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('smartlab_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        localStorage.removeItem('smartlab_user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 800));

    const userRecord = mockUsers[email.toLowerCase()];
    
    if (!userRecord) {
      return { success: false, error: 'Invalid email or password' };
    }

    if (userRecord.password !== password) {
      return { success: false, error: 'Invalid email or password' };
    }

    // Store user in state and localStorage
    setUser(userRecord.user);
    localStorage.setItem('smartlab_user', JSON.stringify(userRecord.user));
    
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('smartlab_user');
  };

  const hasPermission = (requiredRole: UserRole): boolean => {
    if (!user) return false;
    return roleHierarchy[user.role] >= roleHierarchy[requiredRole];
  };

  const hasAnyPermission = (roles: UserRole[]): boolean => {
    if (!user) return false;
    return roles.some(role => roleHierarchy[user.role] >= roleHierarchy[role]);
  };

  const canAccessLab = (labId: string): boolean => {
    if (!user) return false;
    // Admin can access all labs
    if (user.role === 'admin') return true;
    // If assignedLabs is undefined/null, user can access all labs
    if (!user.assignedLabs) return true;
    // Otherwise check if lab is in assigned list
    return user.assignedLabs.includes(labId);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-slate-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
        hasPermission,
        hasAnyPermission,
        canAccessLab,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}